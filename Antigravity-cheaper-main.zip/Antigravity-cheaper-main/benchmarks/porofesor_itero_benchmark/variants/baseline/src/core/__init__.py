"""Core LCU connectivity module."""
